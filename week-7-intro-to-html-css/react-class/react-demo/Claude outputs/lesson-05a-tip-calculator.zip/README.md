# React + TypeScript for Beginners (react-demo-ts)

This is the **TypeScript version** of `react-demo`. It has everything the original had
(Welcome, Bio, Greeting, the click counter and the product list) plus **10 step-by-step lessons**
that build on each other. Every lesson is a page you can click through in the browser.

Built with **Vite** + **React 19** + **TypeScript**, managed with **pnpm**.

---

## 1. Getting started

You need [Node.js](https://nodejs.org) (version 20 or newer) and pnpm.

```bash
# install pnpm once (if you don't have it)
npm install -g pnpm

# inside this folder
pnpm install     # download the packages
pnpm dev         # start the app → open the link it prints (usually http://localhost:5173)
```

Other commands:

| Command        | What it does                                                    |
| -------------- | --------------------------------------------------------------- |
| `pnpm dev`     | Runs the app with hot reload (the page updates when you save)    |
| `pnpm build`   | Checks all the types with `tsc`, then builds the app into `dist/` |
| `pnpm preview` | Serves the built `dist/` folder so you can test it               |
| `pnpm lint`    | Looks for common mistakes with oxlint                            |

> 💡 **Tip:** `pnpm dev` does NOT stop on type errors — it only shows them in your editor.
> `pnpm build` DOES stop on type errors. Run it to check everything before you submit work.

---

## 2. How to use this project

1. Run `pnpm dev` and open the app.
2. Pick a lesson in the sidebar (start with **1**).
3. Lesson **5a** is a hands-on lab: follow its README to build a tip calculator in `TipCalculatorStarter.tsx`.
4. Each lesson page shows:
   - **What you'll learn** — the key ideas
   - **Live demo** — working components you can play with
   - **Try it yourself** — small exercises to do in the code
5. Open the lesson's folder in your editor (the path is shown at the top of each page).
   Every file has comments explaining what is happening. Each folder also has a `README.md` with notes.

---

## 3. The lessons

| #   | Lesson                    | React ideas                                  | TypeScript ideas                                     |
| --- | ------------------------- | -------------------------------------------- | ---------------------------------------------------- |
| 1   | JSX & Components          | components, JSX, `{ }`, fragments            | type inference                                       |
| 2   | Props                     | passing data to children                     | `interface`, optional `?`, defaults, literal unions  |
| 3   | State with useState       | state, re-rendering, conditional rendering   | `useState<number>`, inferred state types             |
| 4   | Lists, Keys & Events      | `.map()`, `key`, click handlers              | shared types, function props `() => void`, `| null`  |
| 5a  | Lab: Tip Calculator 🧪    | controlled input, derived values             | `ChangeEvent`, `Number()`, number literal unions     |
| 5   | Forms & Typed Events      | controlled inputs, submitting forms          | `ChangeEvent`, `SubmitEvent`, `useState<Todo[]>`     |
| 6   | Effects & Loading Data    | `useEffect`, cleanup, loading/error states   | `Promise<T>`, discriminated unions                   |
| 7   | useReducer: Shopping Cart | `useReducer`, `dispatch`, actions            | typed actions, `switch` narrowing                    |
| 8   | Context                   | `createContext`, Providers, `useContext`     | typed context, handling `null`                       |
| 9   | Custom Hooks & Generics   | writing your own hooks, localStorage         | generics `<T>`, return types, `as const`             |
| 10  | Composition & children    | `children`, reusable wrappers                | `ReactNode`, `ComponentProps<'button'>`, `...rest`   |

---

## 4. Project structure

```
react-demo-ts/
├── index.html              ← the single HTML page; loads src/main.tsx
├── package.json            ← project info, scripts and packages
├── tsconfig.json           ← TypeScript settings (points to the two files below)
├── tsconfig.app.json       ← settings for your app code in src/ ("strict": true)
├── tsconfig.node.json      ← settings for vite.config.ts
├── vite.config.ts          ← Vite settings
├── docs/
│   ├── js-vs-ts.md         ← side-by-side: react-demo (JS) vs this project (TS)
│   └── typescript-cheatsheet.md
└── src/
    ├── main.tsx            ← entry point: draws <App /> into <div id="root">
    ├── App.tsx             ← sidebar + the selected lesson
    ├── components/
    │   └── LessonPage.tsx  ← the layout every lesson page uses
    ├── data/products.ts    ← product list (Lessons 4 & 7)
    ├── types/product.ts    ← shared Product / CartItem types
    ├── images/             ← product images (imported, so they work after a build)
    ├── styles/global.css   ← all the styles, incl. light/dark theme
    └── lessons/
        ├── 01-jsx-basics/        Welcome.tsx, Bio.tsx
        ├── 02-props/             Greeting.tsx, Badge.tsx
        ├── 03-state/             Counter.tsx, ToggleMessage.tsx
        ├── 04-lists-and-events/  ProductCard.tsx, ProductList.tsx
        ├── 05a-tip-calculator/   TipCalculatorStarter.tsx (lab), TipCalculator.tsx (answer)
        ├── 05-forms/             TodoApp.tsx
        ├── 06-effects/           Clock.tsx, UserDirectory.tsx, fakeApi.ts
        ├── 07-reducer/           ShoppingCart.tsx, cartReducer.ts
        ├── 08-context/           ThemeContext.ts, ThemeProvider.tsx, ThemeToggle.tsx
        ├── 09-custom-hooks/      useLocalStorage.ts, useToggle.ts, ProfileForm.tsx
        └── 10-composition/       Card.tsx, Button.tsx
```

**File endings:**

- `.ts` — plain TypeScript (no JSX). Used for types, data, hooks and logic.
- `.tsx` — TypeScript **with JSX**. Used for components.

---

## 5. Coming from react-demo (JavaScript)?

Read [`docs/js-vs-ts.md`](docs/js-vs-ts.md). It shows each original file next to its TypeScript version
and explains every change. For quick syntax help, see [`docs/typescript-cheatsheet.md`](docs/typescript-cheatsheet.md).

---

## 6. How this project was created

```bash
pnpm create vite react-demo-ts --template react-ts
cd react-demo-ts
pnpm install
```

Then the template's demo files were replaced with the lessons in `src/lessons/`.
The only config change was adding `"strict": true` to `tsconfig.app.json`, so it is clear that strict type checking is on.
