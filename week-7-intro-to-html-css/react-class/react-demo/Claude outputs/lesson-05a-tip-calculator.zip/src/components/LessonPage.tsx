// components/LessonPage.tsx — the layout every lesson uses.
// It shows the lesson title, what you'll learn, the live demo, and some "try it" exercises.

import type { ReactNode } from 'react';

interface LessonPageProps {
  number: number | string; // a string allows labels like "5a"
  title: string;
  folder: string; // where the code lives, so students can open it
  concepts: string[]; // what this lesson teaches
  tryIt?: string[]; // optional exercises (the `?` means "optional")
  children: ReactNode; // the live demo goes here
}

export default function LessonPage({
  number,
  title,
  folder,
  concepts,
  tryIt = [], // default value used when tryIt is not passed
  children,
}: LessonPageProps) {
  return (
    <article className="lesson">
      <header className="lesson-header">
        <p className="lesson-number">Lesson {number}</p>
        <h1>{title}</h1>
        <p className="lesson-folder">
          📂 Code: <code>src/lessons/{folder}/</code> · 📖 Notes: <code>src/lessons/{folder}/README.md</code>
        </p>
      </header>

      <section className="panel">
        <h2>What you'll learn</h2>
        <ul>
          {concepts.map((concept) => (
            <li key={concept}>{concept}</li>
          ))}
        </ul>
      </section>

      <section className="panel demo">
        <h2>Live demo</h2>
        {children}
      </section>

      {tryIt.length > 0 && (
        <section className="panel try-it">
          <h2>✏️ Try it yourself</h2>
          <ol>
            {tryIt.map((task) => (
              <li key={task}>{task}</li>
            ))}
          </ol>
        </section>
      )}
    </article>
  );
}
