// App.tsx — the main component. It shows a sidebar of lessons and the selected lesson.
// (No router library needed — we just keep "which lesson" in state.)

import type { ComponentType } from 'react';
import Lesson01 from './lessons/01-jsx-basics/Lesson01';
import Lesson02 from './lessons/02-props/Lesson02';
import Lesson03 from './lessons/03-state/Lesson03';
import Lesson04 from './lessons/04-lists-and-events/Lesson04';
import Lesson05 from './lessons/05-forms/Lesson05';
import Lesson05a from './lessons/05a-tip-calculator/Lesson05a';
import Lesson06 from './lessons/06-effects/Lesson06';
import Lesson07 from './lessons/07-reducer/Lesson07';
import Lesson08 from './lessons/08-context/Lesson08';
import ThemeProvider from './lessons/08-context/ThemeProvider';
import ThemeToggle from './lessons/08-context/ThemeToggle';
import { useLocalStorage } from './lessons/09-custom-hooks/useLocalStorage';
import Lesson09 from './lessons/09-custom-hooks/Lesson09';
import Lesson10 from './lessons/10-composition/Lesson10';

interface Lesson {
  id: string; // a string, so we can have lessons like "5a"
  title: string;
  component: ComponentType; // "a React component" (one that takes no props)
}

// The order of this array is the order in the sidebar (and for Previous / Next).
const LESSONS: Lesson[] = [
  { id: '1', title: 'JSX & Components', component: Lesson01 },
  { id: '2', title: 'Props (with Types)', component: Lesson02 },
  { id: '3', title: 'State with useState', component: Lesson03 },
  { id: '4', title: 'Lists, Keys & Events', component: Lesson04 },
  { id: '5a', title: 'Lab: Tip Calculator', component: Lesson05a },
  { id: '5', title: 'Forms & Typed Events', component: Lesson05 },
  { id: '6', title: 'Effects & Loading Data', component: Lesson06 },
  { id: '7', title: 'useReducer: Shopping Cart', component: Lesson07 },
  { id: '8', title: 'Context', component: Lesson08 },
  { id: '9', title: 'Custom Hooks & Generics', component: Lesson09 },
  { id: '10', title: 'Composition & children', component: Lesson10 },
];

export default function App() {
  // Remember the open lesson even after a refresh (custom hook from Lesson 9)
  const [currentId, setCurrentId] = useLocalStorage<string>('current-lesson-id', '1');

  // findIndex returns -1 when nothing matches, so we fall back to the first lesson (index 0)
  const foundIndex = LESSONS.findIndex((lesson) => lesson.id === currentId);
  const currentIndex = foundIndex === -1 ? 0 : foundIndex;
  const current = LESSONS[currentIndex];
  const CurrentLesson = current.component; // must start with a capital to use as <CurrentLesson />

  return (
    <ThemeProvider>
      <div className="app">
        <nav className="sidebar">
          <p className="brand">⚛️ React + TS</p>
          <ThemeToggle />
          <ol>
            {LESSONS.map((lesson) => (
              <li key={lesson.id}>
                <button
                  className={lesson.id === current.id ? 'nav-link active' : 'nav-link'}
                  onClick={() => setCurrentId(lesson.id)}
                >
                  <span className="nav-number">{lesson.id}</span> {lesson.title}
                </button>
              </li>
            ))}
          </ol>
        </nav>

        <main className="content">
          {/* key forces a fresh lesson (fresh state) each time you switch */}
          <CurrentLesson key={current.id} />

          <div className="pager">
            <button
              className="secondary"
              disabled={currentIndex === 0}
              onClick={() => setCurrentId(LESSONS[currentIndex - 1].id)}
            >
              ← Previous
            </button>
            <button
              disabled={currentIndex === LESSONS.length - 1}
              onClick={() => setCurrentId(LESSONS[currentIndex + 1].id)}
            >
              Next →
            </button>
          </div>
        </main>
      </div>
    </ThemeProvider>
  );
}
