// TipCalculatorStarter.tsx — YOUR lab file. 🧪
//
// Follow the steps in README.md (same folder). Save after each step:
// your work appears live under "Your version" on the Lesson 5a page.
//
// When you're stuck, peek at TipCalculator.tsx — but try first!

// STEP 1: import useState (and the ChangeEvent type) from 'react'

// STEP 3: create a TipPercent type (10 | 15 | 20) and a TIP_OPTIONS array

// STEP 2: write formatMoney(amount: number): string

export default function TipCalculatorStarter() {
  // STEP 1: a `bill` state (a string) and a handleBillChange function

  // STEP 3: a `tipPercent` state of type TipPercent

  // STEP 4: a `people` state (a number, starting at 1)

  // STEP 2: derived values — billAmount, tip, total (STEP 4: perPerson)

  return (
    <div className="stack">
      <p>Start with Step 1 in README.md. Replace this paragraph with your calculator!</p>
      {/* STEP 1: the bill <input> */}
      {/* STEP 3: the tip buttons */}
      {/* STEP 4: the people − / + buttons */}
      {/* STEP 2: show the tip and total */}
      {/* STEP 5: a Reset button */}
    </div>
  );
}
