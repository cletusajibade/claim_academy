import { useState } from 'react';
import LessonPage from '../../components/LessonPage';
import TipCalculator from './TipCalculator';
import TipCalculatorStarter from './TipCalculatorStarter';

export default function Lesson05a() {
  const [showFinished, setShowFinished] = useState(false);

  return (
    <LessonPage
      number="5a"
      title="Lab: Tip Calculator"
      folder="05a-tip-calculator"
      concepts={[
        'Controlled input: value={bill} + onChange',
        'Typing an event: ChangeEvent<HTMLInputElement>',
        'Inputs give you text: convert with Number()',
        'A union of number literals: type TipPercent = 10 | 15 | 20',
        'A typed helper function: formatMoney(amount: number): string',
        'Derived values: tip and total are calculated, not stored',
      ]}
      tryIt={[
        'Open README.md in this folder and build the calculator in TipCalculatorStarter.tsx, one step at a time.',
        'Bonus: disable the − button when people is 1 (disabled={people === 1}).',
        'Bonus: add a 25% option. Which TWO places do you need to change?',
      ]}
    >
      <h3>Your version</h3>
      <TipCalculatorStarter />

      <hr />

      <button className="secondary" onClick={() => setShowFinished(!showFinished)}>
        {showFinished ? 'Hide' : 'Show'} the finished version
      </button>
      {showFinished && (
        <div className="nested">
          <TipCalculator />
        </div>
      )}
    </LessonPage>
  );
}
