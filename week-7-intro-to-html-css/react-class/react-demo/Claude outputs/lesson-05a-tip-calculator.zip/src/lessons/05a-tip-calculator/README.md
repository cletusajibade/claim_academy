# Lesson 5a — Lab: Tip Calculator 🧪

**Time:** about 45 minutes · **Do it in:** `TipCalculatorStarter.tsx` · **Answer key:** `TipCalculator.tsx`

You'll build a calculator that splits a restaurant bill:

```
Bill amount ($): [ 80        ]
Tip:  [10%] [15%] [20%]
People:  −  2  +
Tip: $12.00   Total: $92.00
Each person pays: $46.00
[Reset]
```

Run `pnpm dev`, open **Lesson 5a**, and keep it next to your editor.
Every time you save, your work appears under **"Your version"**.

---

## Step 1 — The bill input

Make the input **controlled**: React state holds what's typed.

```tsx
import { useState } from 'react';
import type { ChangeEvent } from 'react';

// inside the component:
const [bill, setBill] = useState('');

function handleBillChange(e: ChangeEvent<HTMLInputElement>) {
  setBill(e.target.value);
}

// inside the return:
<label>
  Bill amount ($):{' '}
  <input type="number" value={bill} onChange={handleBillChange} />
</label>
<p>You typed: {bill}</p>
```

✅ **Check:** typing in the box updates "You typed: …".

💡 **Why is `bill` a string?** An `<input>` *always* gives you text, even with `type="number"`.
Hover over `e.target.value` in VS Code: it says `string`.

---

## Step 2 — Do the maths (15% for now)

Convert the text to a number, then calculate. These are **derived values**: work them out
from state every render. Don't put them in state.

```tsx
// above the component:
function formatMoney(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

// inside the component, after the state:
const billAmount = Number(bill) || 0; // "" or junk → 0
const tip = (billAmount * 15) / 100;
const total = billAmount + tip;

// inside the return (replace "You typed"):
<p>Tip: {formatMoney(tip)}</p>
<p>Total: {formatMoney(total)}</p>
```

✅ **Check:** a bill of 100 shows Tip: $15.00 and Total: $115.00.

🔨 **Break it:** try `const tip = (bill * 15) / 100;` (using the string). Read the error.
Then try `formatMoney('5')`. TypeScript catches both before you run anything.

---

## Step 3 — Choose the tip

Only 10, 15 and 20 are allowed, so make a type that says exactly that.

```tsx
// above the component:
type TipPercent = 10 | 15 | 20;
const TIP_OPTIONS: TipPercent[] = [10, 15, 20];

// inside the component:
const [tipPercent, setTipPercent] = useState<TipPercent>(15);

// change the tip line to use it:
const tip = (billAmount * tipPercent) / 100;

// inside the return:
<div className="row">
  <span>Tip:</span>
  {TIP_OPTIONS.map((percent) => (
    <button
      key={percent}
      className={percent === tipPercent ? '' : 'secondary'}
      onClick={() => setTipPercent(percent)}
    >
      {percent}%
    </button>
  ))}
</div>
```

✅ **Check:** clicking 20% highlights it and the tip changes.

🔨 **Break it:** write `setTipPercent(12)`. Why does TypeScript refuse?

---

## Step 4 — Split between people

```tsx
const [people, setPeople] = useState(1);
const perPerson = total / people;

// inside the return:
<div className="row">
  <span>People:</span>
  <button onClick={() => setPeople(Math.max(1, people - 1))}>−</button>
  <strong>{people}</strong>
  <button onClick={() => setPeople(people + 1)}>+</button>
</div>
<p className="big-number">Each person pays: {formatMoney(perPerson)}</p>
```

✅ **Check:** people never goes below 1 (`Math.max` makes sure of that, so we never divide by 0).

---

## Step 5 — Reset

```tsx
function reset() {
  setBill('');
  setTipPercent(15);
  setPeople(1);
}

<button onClick={reset}>Reset</button>
```

✅ **Check:** Reset puts everything back to the start. **You're done!** 🎉
Compare with **Show the finished version** on the lesson page.

---

## Bonus challenges

1. Disable the − button when `people === 1` (`disabled={...}`).
2. Add a 25% option. Which **two** places must change? (Hint: the type and the array.)
3. Show a message when the bill is negative.
4. Move the tip buttons into their own component with props
   `selected: TipPercent` and `onSelect: (percent: TipPercent) => void`.

## What you practised

| Idea | Where |
| --- | --- |
| `useState` with a string, a number and a custom type | Steps 1, 3, 4 |
| Controlled input + `ChangeEvent<HTMLInputElement>` | Step 1 |
| Text → number with `Number()` | Step 2 |
| A typed function: `(amount: number): string` | Step 2 |
| A union of literal values: `10 \| 15 \| 20` | Step 3 |
| Rendering a list with `.map()` and `key` | Step 3 |
| Derived values instead of extra state | Steps 2, 4 |

When this feels easy, move on to **Lesson 5 (To-do list)**: same ideas, plus arrays of objects in state.
