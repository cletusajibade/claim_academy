// TipCalculator.tsx — the FINISHED lab (the answer key).
// Students build their own version in TipCalculatorStarter.tsx by following README.md.

import { useState } from 'react';
import type { ChangeEvent } from 'react';

// A union of NUMBER literals: only these three tip amounts are allowed.
type TipPercent = 10 | 15 | 20;
const TIP_OPTIONS: TipPercent[] = [10, 15, 20];

// A small typed helper: takes a number, gives back a string like "$12.50".
function formatMoney(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export default function TipCalculator() {
  // An <input> always gives us TEXT, so the bill is stored as a string.
  const [bill, setBill] = useState('');
  const [tipPercent, setTipPercent] = useState<TipPercent>(15);
  const [people, setPeople] = useState(1);

  function handleBillChange(e: ChangeEvent<HTMLInputElement>) {
    setBill(e.target.value);
  }

  function reset() {
    setBill('');
    setTipPercent(15);
    setPeople(1);
  }

  // DERIVED values: calculated on every render, never stored in state.
  const billAmount = Number(bill) || 0; // turn text into a number ("" → 0)
  const tip = (billAmount * tipPercent) / 100;
  const total = billAmount + tip;
  const perPerson = total / people;

  return (
    <div className="stack">
      <label>
        Bill amount ($):{' '}
        <input type="number" value={bill} onChange={handleBillChange} placeholder="0.00" />
      </label>

      <div className="row">
        <span>Tip:</span>
        {TIP_OPTIONS.map((percent) => (
          <button
            key={percent}
            className={percent === tipPercent ? '' : 'secondary'}
            onClick={() => setTipPercent(percent)}
          >
            {percent}%
          </button>
        ))}
      </div>

      <div className="row">
        <span>People:</span>
        <button className="small" onClick={() => setPeople(Math.max(1, people - 1))}>
          −
        </button>
        <strong>{people}</strong>
        <button className="small" onClick={() => setPeople(people + 1)}>
          +
        </button>
      </div>

      <div className="callout">
        <p>Tip: {formatMoney(tip)}</p>
        <p>Total: {formatMoney(total)}</p>
        <p className="big-number">Each person pays: {formatMoney(perPerson)}</p>
      </div>

      <button className="secondary" onClick={reset}>
        Reset
      </button>
    </div>
  );
}
